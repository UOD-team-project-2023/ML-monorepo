#!/bin/bash

cd /opt/monitorLizard/ML-Api

if [ -d "venv" ] 
then
    echo "venv found." 
else
    echo "creating venv."
    python3 -m venv venv
fi


source venv/bin/activate
pip3 install -r requirements.txt
python3 main.py